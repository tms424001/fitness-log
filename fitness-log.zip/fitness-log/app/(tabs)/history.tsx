import { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useWorkoutStore } from '../../src/store/useWorkoutStore';
import type { WorkoutLog } from '../../src/types/workout';

export default function History() {
  const { workouts, loading, error, fetchWorkouts, removeWorkout } = useWorkoutStore();

  useEffect(() => {
    fetchWorkouts();
  }, []);

  const handleDelete = (item: WorkoutLog) => {
    Alert.alert(
      '确认删除',
      `确定要删除 ${item.workout_date} 的 ${getTypeLabel(item.workout_type)} 记录吗？`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '删除',
          style: 'destructive',
          onPress: async () => {
            try {
              await removeWorkout(item.id);
              Alert.alert('成功', '记录已删除');
            } catch (err) {
              Alert.alert('错误', (err as Error).message);
            }
          },
        },
      ]
    );
  };

  const renderItem = ({ item }: { item: WorkoutLog }) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardType}>{getTypeLabel(item.workout_type)}</Text>
        <Text style={styles.cardDate}>{item.workout_date}</Text>
      </View>
      <View style={styles.cardBody}>
        <View style={styles.cardStat}>
          <Text style={styles.statValue}>{item.duration_min}</Text>
          <Text style={styles.statLabel}>分钟</Text>
        </View>
        <View style={styles.cardStat}>
          <Text style={styles.statValue}>{getIntensityLabel(item.intensity)}</Text>
          <Text style={styles.statLabel}>强度</Text>
        </View>
      </View>
      {item.notes && (
        <Text style={styles.cardNotes}>{item.notes}</Text>
      )}
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDelete(item)}
      >
        <Text style={styles.deleteButtonText}>删除</Text>
      </TouchableOpacity>
    </View>
  );

  if (loading && workouts.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#4F46E5" />
        <Text style={styles.loadingText}>加载中...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={fetchWorkouts}>
          <Text style={styles.retryButtonText}>重试</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={workouts}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={fetchWorkouts} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>暂无记录</Text>
            <Text style={styles.emptyHint}>点击底部 "Add" 开始记录</Text>
          </View>
        }
      />
    </View>
  );
}

function getTypeLabel(type: string): string {
  const map: Record<string, string> = {
    strength: '💪 力量训练',
    cardio: '🏃 有氧运动',
    yoga: '🧘 瑜伽',
    hiit: '🔥 HIIT',
    other: '🏋️ 其他',
  };
  return map[type] || type;
}

function getIntensityLabel(intensity: string): string {
  const map: Record<string, string> = {
    low: '低',
    medium: '中',
    high: '高',
  };
  return map[intensity] || intensity;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    padding: 20,
  },
  listContent: {
    padding: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardType: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
  },
  cardDate: {
    fontSize: 14,
    color: '#6B7280',
  },
  cardBody: {
    flexDirection: 'row',
    gap: 24,
  },
  cardStat: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4F46E5',
  },
  statLabel: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  cardNotes: {
    fontSize: 13,
    color: '#6B7280',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    fontStyle: 'italic',
  },
  deleteButton: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#EF4444',
    fontSize: 14,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    color: '#9CA3AF',
    marginBottom: 8,
  },
  emptyHint: {
    fontSize: 14,
    color: '#D1D5DB',
  },
  loadingText: {
    marginTop: 12,
    color: '#6B7280',
  },
  errorText: {
    color: '#EF4444',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
});
